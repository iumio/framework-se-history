<?php

namespace deadApp;

use iumioFramework\Core\Requirement\AppModel as App;

/**
 * Class deadApp
 * @package deadApp
 */

class deadApp extends App
{
    /*** REGISTER TO APP ***/
}