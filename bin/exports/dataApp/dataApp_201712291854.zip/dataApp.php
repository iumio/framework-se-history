<?php

namespace dataApp;

use iumioFramework\Core\Requirement\AppModel as App;

/**
 * Class dataApp
 * @package dataApp
 */

class dataApp extends App
{
    /*** REGISTER TO APP ***/
}