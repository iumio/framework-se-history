<?php

namespace DocApp;

use iumioFramework\Core\Requirement\iumioAppModel as App;

/**
 * Class DocApp
 * @package DocApp
 */

class DocApp extends App
{
    /*** REGISTER TO APP ***/

}
