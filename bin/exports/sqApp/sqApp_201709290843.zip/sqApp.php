<?php

namespace sqApp;

use iumioFramework\Core\Requirement\AppModel as App;

/**
 * Class sqApp
 * @package sqApp
 */

class sqApp extends App
{
    /*** REGISTER TO APP ***/
}
