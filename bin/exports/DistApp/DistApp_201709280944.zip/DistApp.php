<?php

namespace DistApp;

use iumioFramework\Core\Requirement\iumioAppModel as App;

/**
 * Class DistApp
 * @package DistApp
 */

class DistApp extends App
{
    /*** REGISTER TO APP ***/

}
