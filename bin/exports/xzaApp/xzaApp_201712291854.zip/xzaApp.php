<?php

namespace xzaApp;

use iumioFramework\Core\Requirement\AppModel as App;

/**
 * Class xzaApp
 * @package xzaApp
 */

class xzaApp extends App
{
    /*** REGISTER TO APP ***/
}