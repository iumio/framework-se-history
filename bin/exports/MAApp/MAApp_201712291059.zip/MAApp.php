<?php

namespace MAApp;

use iumioFramework\Core\Requirement\AppModel as App;

/**
 * Class MAApp
 * @package MAApp
 */

class MAApp extends App
{
    /*** REGISTER TO APP ***/
}